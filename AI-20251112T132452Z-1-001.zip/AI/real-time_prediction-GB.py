import os
import pandas as pd
import numpy as np
import joblib
from datetime import datetime, timedelta, timezone
import firebase_admin
from firebase_admin import credentials, db

# =====================================================
# 0. Initialize Firebase
# =====================================================
def initialize_firebase():
    """Initialize Firebase Admin SDK"""
    try:
        firebase_admin.get_app()
        print("✓ Firebase already initialized")
    except ValueError:
        cred = credentials.Certificate('airhaven-database-firebase-adminsdk-fbsvc-83163557d5.json')
        firebase_admin.initialize_app(cred, {
            'databaseURL': 'https://airhaven-database-default-rtdb.asia-southeast1.firebasedatabase.app/'
        })
        print("✓ Firebase initialized successfully")

# =====================================================
# 1. Fetch data from Firebase (MINUTE-LEVEL)
# =====================================================
def fetch_firebase_data(hours=168):
    """
    Fetch minute-level historical data from Firebase
    
    Args:
        hours: Number of hours of historical data to fetch
    
    Returns:
        pandas DataFrame with minute-level sensor data
    """
    print(f"\n✓ Attempting to fetch last {hours} hours of minute-level data from Firebase...")
    print(f"  Expected records: ~{hours * 60:,} readings")
    
    ref = db.reference('sensor_data/history')
    
    # Calculate time range
    end_time = datetime.now(timezone(timedelta(hours=8)))
    start_time = end_time - timedelta(hours=hours)
    
    # Fetch data
    all_data = []
    
    # Query by date range
    for single_date in pd.date_range(start_time.date(), end_time.date(), freq='D'):
        date_str = single_date.strftime('%Y-%m-%d')
        date_ref = ref.child(date_str)
        date_data = date_ref.get()
        
        if date_data:
            for timestamp, values in date_data.items():
                if values:
                    record = {
                        'datetime': values.get('timestamp'),
                        'components.pm2_5': values.get('PM25'),
                        'components.pm10': values.get('PM10'),
                        'humidity': values.get('humidity'),
                        'temperature': values.get('temperature'),
                        'rssi': values.get('rssi')
                    }
                    all_data.append(record)
    
    if not all_data:
        print("⚠ No data found in specified date range. Fetching ALL available data...")
        all_history = ref.get()
        if all_history:
            for date_key, date_data in all_history.items():
                if date_data:
                    for timestamp, values in date_data.items():
                        if values:
                            record = {
                                'datetime': values.get('timestamp'),
                                'components.pm2_5': values.get('PM25'),
                                'components.pm10': values.get('PM10'),
                                'humidity': values.get('humidity'),
                                'temperature': values.get('temperature'),
                                'rssi': values.get('rssi')
                            }
                            all_data.append(record)
    
    df = pd.DataFrame(all_data)
    print(f"✓ Retrieved {len(df):,} minute-level records from Firebase")
    
    if len(df) == 0:
        raise ValueError("No data available in Firebase. Please ensure sensor data is being uploaded.")
    
    return df

# =====================================================
# 2. Extract hourly readings (take reading at each hour mark)
# =====================================================
def extract_hourly_readings(df):
    """
    Extract hourly readings from minute-level data
    Takes the reading closest to each hour mark (XX:00:00)
    
    This matches how DENR-EMB provides hourly data - one reading per hour
    """
    print(f"\n✓ Extracting hourly readings from {len(df):,} minute-level records...")
    
    # Parse datetime
    df['datetime'] = pd.to_datetime(df['datetime'], errors='coerce')
    df = df.dropna(subset=['datetime'])
    df = df.sort_values('datetime')
    
    # Clean PM values
    df['components.pm2_5'] = pd.to_numeric(df['components.pm2_5'], errors='coerce')
    df['components.pm10'] = pd.to_numeric(df['components.pm10'], errors='coerce')
    
    # Remove invalid values
    df.loc[(df['components.pm2_5'] < 0) | (df['components.pm2_5'] > 1000), 'components.pm2_5'] = np.nan
    df.loc[(df['components.pm10'] < 0) | (df['components.pm10'] > 1000), 'components.pm10'] = np.nan
    
    df = df.dropna(subset=['components.pm2_5', 'components.pm10'])
    
    # Round datetime to nearest hour to group readings
    df['hour_mark'] = df['datetime'].dt.floor('h')
    
    # For each hour, take the reading closest to XX:00:00
    # Calculate how far each reading is from its hour mark
    df['distance_from_hour'] = abs((df['datetime'] - df['hour_mark']).dt.total_seconds())
    
    # Get the reading closest to each hour mark
    hourly_df = df.loc[df.groupby('hour_mark')['distance_from_hour'].idxmin()].copy()
    
    # Use the hour mark as the official datetime
    hourly_df['datetime'] = hourly_df['hour_mark']
    hourly_df = hourly_df.drop(columns=['hour_mark', 'distance_from_hour'])
    hourly_df = hourly_df.sort_values('datetime').reset_index(drop=True)
    
    print(f"✓ Extracted {len(hourly_df)} hourly readings")
    print(f"  Date range: {hourly_df['datetime'].min()} to {hourly_df['datetime'].max()}")
    print(f"  Hours of data: {len(hourly_df)}")
    
    # Data quality check
    if len(hourly_df) > 1:
        expected_hours = (hourly_df['datetime'].max() - hourly_df['datetime'].min()).total_seconds() / 3600 + 1
        completeness = (len(hourly_df) / expected_hours * 100) if expected_hours > 0 else 0
        print(f"  Data completeness: {completeness:.1f}%")
        
        if completeness < 80:
            print(f"  ⚠ Warning: {100-completeness:.1f}% of hours are missing data")
    
    return hourly_df

# =====================================================
# 3. Load trained models
# =====================================================
pm25_model_path = os.path.join("saved_models", "components_pm2_5_gradient_boosting.pkl")
pm10_model_path = os.path.join("saved_models", "components_pm10_gradient_boosting.pkl")

if not (os.path.exists(pm25_model_path) and os.path.exists(pm10_model_path)):
    raise FileNotFoundError("Trained Gradient Boosting models not found.")

model_pm25 = joblib.load(pm25_model_path)
model_pm10 = joblib.load(pm10_model_path)
print("✓ Gradient Boosting models loaded successfully.")

# =====================================================
# 4. Data preprocessing functions
# =====================================================
def preprocess_data(df):
    """Preprocess the extracted hourly data"""
    # Already cleaned during extraction
    print(f"✓ Preprocessed {len(df)} valid hourly data points")
    return df

def generate_features(df):
    """Generate all features matching the training script"""
    print("\n✓ Generating enhanced features...")
    
    # Quality features
    df['pm2_5_is_missing'] = 0
    df['pm10_is_missing'] = 0
    df['pm2_5_missing_count_6h'] = 0
    df['pm10_missing_count_6h'] = 0
    df['pm2_5_imputed'] = df['components.pm2_5']
    df['pm10_imputed'] = df['components.pm10']
    
    # Temporal features
    df['month'] = df['datetime'].dt.month
    df['day'] = df['datetime'].dt.day
    df['dayofweek'] = df['datetime'].dt.dayofweek
    df['hour'] = df['datetime'].dt.hour
    df['is_weekend'] = (df['dayofweek'] >= 5).astype(int)
    df['is_dry_season'] = df['month'].isin([11, 12, 1, 2, 3, 4]).astype(int)
    
    # Cyclical encoding
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
    df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
    df['is_rush_hour'] = df['hour'].isin([7, 8, 9, 17, 18, 19, 20]).astype(int)
    
    # Lag features (hourly lags) - handle insufficient data
    for lag in range(1, 13):
        df[f'pm2_5_lag{lag}'] = df['pm2_5_imputed'].shift(lag).fillna(df['pm2_5_imputed'].iloc[0])
        df[f'pm10_lag{lag}'] = df['pm10_imputed'].shift(lag).fillna(df['pm10_imputed'].iloc[0])
    
    # Lag interactions
    df['pm_ratio_lag1'] = df['pm2_5_lag1'] / (df['pm10_lag1'] + 1)
    df['pm_ratio_lag3'] = df['pm2_5_lag3'] / (df['pm10_lag3'] + 1)
    df['pm_diff_lag1'] = df['pm10_lag1'] - df['pm2_5_lag1']
    
    # Rolling statistics (in hours) - handle insufficient data
    windows = [3, 6, 12, 24, 48]
    for window in windows:
        min_periods = 1  # Accept even 1 data point for cold start
        df[f'pm2_5_roll_median_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).median().shift(1).ffill()
        df[f'pm10_roll_median_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).median().shift(1).ffill()
        df[f'pm2_5_roll_std_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).std().shift(1).fillna(0)
        df[f'pm10_roll_std_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).std().shift(1).fillna(0)
        df[f'pm2_5_roll_min_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).min().shift(1).ffill()
        df[f'pm2_5_roll_max_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).max().shift(1).ffill()
        df[f'pm10_roll_min_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).min().shift(1).ffill()
        df[f'pm10_roll_max_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).max().shift(1).ffill()
    
    # Rate of change (hourly) - handle insufficient data
    for lag in [1, 3, 6]:
        df[f'pm2_5_change_{lag}h'] = df['pm2_5_imputed'].diff(lag).fillna(0)
        df[f'pm10_change_{lag}h'] = df['pm10_imputed'].diff(lag).fillna(0)
    
    df['pm2_5_accel'] = df['pm2_5_change_1h'].diff(1).fillna(0)
    df['pm10_accel'] = df['pm10_change_1h'].diff(1).fillna(0)
    
    # EWMA - handle insufficient data
    df['pm2_5_ewm_12h'] = df['pm2_5_imputed'].ewm(span=12, min_periods=1).mean().shift(1).bfill()
    df['pm10_ewm_12h'] = df['pm10_imputed'].ewm(span=12, min_periods=1).mean().shift(1).bfill()
    
    # Remove rows that still have NaN (should be minimal now)
    initial_rows = len(df)
    df = df.dropna().reset_index(drop=True)
    dropped_rows = initial_rows - len(df)
    
    if dropped_rows > 0:
        print(f"  Note: Dropped {dropped_rows} rows due to remaining NaN values")
    
    return df

# Define feature list
TEMPORAL_FEATURES = ['month', 'day', 'dayofweek', 'hour', 'is_weekend', 'is_dry_season', 
                     'hour_sin', 'hour_cos', 'month_sin', 'month_cos', 'is_rush_hour']
LAG_FEATURES = [f'pm2_5_lag{i}' for i in range(1, 13)] + [f'pm10_lag{i}' for i in range(1, 13)]
INTERACTION_FEATURES = ['pm_ratio_lag1', 'pm_ratio_lag3', 'pm_diff_lag1']
ROLLING_FEATURES = []
for window in [3, 6, 12, 24, 48]:
    ROLLING_FEATURES.extend([
        f'pm2_5_roll_median_{window}h', f'pm10_roll_median_{window}h',
        f'pm2_5_roll_std_{window}h', f'pm10_roll_std_{window}h',
        f'pm2_5_roll_min_{window}h', f'pm2_5_roll_max_{window}h',
        f'pm10_roll_min_{window}h', f'pm10_roll_max_{window}h'
    ])
CHANGE_FEATURES = [f'pm2_5_change_{i}h' for i in [1, 3, 6]] + \
                  [f'pm10_change_{i}h' for i in [1, 3, 6]] + \
                  ['pm2_5_accel', 'pm10_accel']
EWM_FEATURES = ['pm2_5_ewm_12h', 'pm10_ewm_12h']
QUALITY_FEATURES = ['pm2_5_missing_count_6h', 'pm10_missing_count_6h']

MODEL_FEATURES = (TEMPORAL_FEATURES + LAG_FEATURES + INTERACTION_FEATURES + 
                  ROLLING_FEATURES + CHANGE_FEATURES + EWM_FEATURES + QUALITY_FEATURES)

# =====================================================
# 5. Generate forecast
# =====================================================
def generate_forecast(df, hours=48):
    """Generate hourly forecast for specified hours"""
    
    # Check data sufficiency
    data_hours = len(df)
    print(f"\n✓ Available hourly data points: {data_hours}")
    
    if data_hours < 12:
        print("⚠ WARNING: Less than 12 hours of data available.")
        print("  Forecast will be generated but accuracy may be limited.")
        print("  Recommendation: Collect at least 48 hours of data for reliable forecasts.")
    elif data_hours < 48:
        print(f"⚠ Note: Only {data_hours} hours of data available (recommended: 48+)")
        print("  Forecast will be generated with available data.")
    
    print("\n" + "="*70)
    print(f"GENERATING {hours}-HOUR FORECAST")
    print("="*70)
    
    forecast_results = []
    current_time = datetime.now(timezone(timedelta(hours=8)))
    
    # Get historical data (use all available if less than 48)
    history_length = min(48, len(df))
    historical_pm25 = list(df['components.pm2_5'].tail(history_length))
    historical_pm10 = list(df['components.pm10'].tail(history_length))
    
    print(f"\nCurrent time: {current_time.strftime('%Y-%m-%d %H:%M:%S')} (Philippine Time)")
    print(f"Last measurement: {df['datetime'].iloc[-1]}")
    print(f"  PM2.5: {df['components.pm2_5'].iloc[-1]:.2f} μg/m³")
    print(f"  PM10: {df['components.pm10'].iloc[-1]:.2f} μg/m³")
    print(f"Using last {history_length} hourly data points for forecast initialization")
    
    for i in range(1, hours + 1):
        forecast_time = current_time + timedelta(hours=i)
        
        # Build features
        temp = {
            'month': forecast_time.month,
            'day': forecast_time.day,
            'dayofweek': forecast_time.weekday(),
            'hour': forecast_time.hour,
            'is_weekend': int(forecast_time.weekday() >= 5),
            'is_dry_season': int(forecast_time.month in [11, 12, 1, 2, 3, 4]),
            'hour_sin': np.sin(2 * np.pi * forecast_time.hour / 24),
            'hour_cos': np.cos(2 * np.pi * forecast_time.hour / 24),
            'month_sin': np.sin(2 * np.pi * forecast_time.month / 12),
            'month_cos': np.cos(2 * np.pi * forecast_time.month / 12),
            'is_rush_hour': int(forecast_time.hour in [7, 8, 9, 17, 18, 19, 20]),
        }
        
        # Lag features
        for lag in range(1, 13):
            if lag <= len(historical_pm25):
                temp[f'pm2_5_lag{lag}'] = historical_pm25[-lag]
                temp[f'pm10_lag{lag}'] = historical_pm10[-lag]
            else:
                temp[f'pm2_5_lag{lag}'] = historical_pm25[0]
                temp[f'pm10_lag{lag}'] = historical_pm10[0]
        
        # Interactions
        temp['pm_ratio_lag1'] = temp['pm2_5_lag1'] / (temp['pm10_lag1'] + 1)
        temp['pm_ratio_lag3'] = temp['pm2_5_lag3'] / (temp['pm10_lag3'] + 1)
        temp['pm_diff_lag1'] = temp['pm10_lag1'] - temp['pm2_5_lag1']
        
        # Rolling stats
        for window in [3, 6, 12, 24, 48]:
            window_data_pm25 = historical_pm25[-window:] if len(historical_pm25) >= window else historical_pm25
            window_data_pm10 = historical_pm10[-window:] if len(historical_pm10) >= window else historical_pm10
            
            temp[f'pm2_5_roll_median_{window}h'] = np.median(window_data_pm25)
            temp[f'pm10_roll_median_{window}h'] = np.median(window_data_pm10)
            temp[f'pm2_5_roll_std_{window}h'] = np.std(window_data_pm25)
            temp[f'pm10_roll_std_{window}h'] = np.std(window_data_pm10)
            temp[f'pm2_5_roll_min_{window}h'] = np.min(window_data_pm25)
            temp[f'pm2_5_roll_max_{window}h'] = np.max(window_data_pm25)
            temp[f'pm10_roll_min_{window}h'] = np.min(window_data_pm10)
            temp[f'pm10_roll_max_{window}h'] = np.max(window_data_pm10)
        
        # Rate of change
        for lag in [1, 3, 6]:
            if lag < len(historical_pm25):
                temp[f'pm2_5_change_{lag}h'] = historical_pm25[-1] - historical_pm25[-lag-1]
                temp[f'pm10_change_{lag}h'] = historical_pm10[-1] - historical_pm10[-lag-1]
            else:
                temp[f'pm2_5_change_{lag}h'] = 0
                temp[f'pm10_change_{lag}h'] = 0
        
        # Acceleration
        if len(historical_pm25) >= 2:
            recent_change_pm25 = historical_pm25[-1] - historical_pm25[-2]
            prev_change_pm25 = historical_pm25[-2] - historical_pm25[-3] if len(historical_pm25) >= 3 else 0
            temp['pm2_5_accel'] = recent_change_pm25 - prev_change_pm25
            
            recent_change_pm10 = historical_pm10[-1] - historical_pm10[-2]
            prev_change_pm10 = historical_pm10[-2] - historical_pm10[-3] if len(historical_pm10) >= 3 else 0
            temp['pm10_accel'] = recent_change_pm10 - prev_change_pm10
        else:
            temp['pm2_5_accel'] = 0
            temp['pm10_accel'] = 0
        
        # EWMA
        span = 12
        if len(historical_pm25) >= span:
            weights = np.exp(np.linspace(-1., 0., span))
            weights /= weights.sum()
            temp['pm2_5_ewm_12h'] = np.average(historical_pm25[-span:], weights=weights)
            temp['pm10_ewm_12h'] = np.average(historical_pm10[-span:], weights=weights)
        else:
            temp['pm2_5_ewm_12h'] = np.mean(historical_pm25)
            temp['pm10_ewm_12h'] = np.mean(historical_pm10)
        
        # Quality features
        temp['pm2_5_missing_count_6h'] = 0
        temp['pm10_missing_count_6h'] = 0
        
        # Predict
        X_pred = pd.DataFrame([temp])[MODEL_FEATURES]
        pm25_next = max(0, min(1000, model_pm25.predict(X_pred)[0]))
        pm10_next = max(0, min(1000, model_pm10.predict(X_pred)[0]))
        
        # Update history
        historical_pm25.append(pm25_next)
        historical_pm10.append(pm10_next)
        if len(historical_pm25) > 48:
            historical_pm25.pop(0)
            historical_pm10.pop(0)
        
        forecast_results.append({
            'forecast_time': forecast_time,
            'pm25_forecast': pm25_next,
            'pm10_forecast': pm10_next
        })
    
    return pd.DataFrame(forecast_results)

# =====================================================
# 6. Save forecast to Firebase
# =====================================================
def save_forecast_to_firebase(forecast_df):
    """Save forecast results to Firebase"""
    print("\n✓ Saving forecast to Firebase...")
    
    ref = db.reference('sensor_data/forecast')
    
    # Clear old forecasts
    ref.delete()
    
    # Save new forecast
    for _, row in forecast_df.iterrows():
        timestamp_str = row['forecast_time'].strftime('%Y-%m-%d %H:%M:%S')
        forecast_data = {
            'timestamp': timestamp_str,
            'PM25': round(row['pm25_forecast'], 2),
            'PM10': round(row['pm10_forecast'], 2),
            'generated_at': datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Use timestamp as key
        date_key = row['forecast_time'].strftime('%Y-%m-%d')
        time_key = row['forecast_time'].strftime('%H:%M:%S')
        ref.child(date_key).child(time_key).set(forecast_data)
    
    print(f"✓ Saved {len(forecast_df)} forecast records to Firebase")

# =====================================================
# 7. Main execution
# =====================================================
def main():
    # Initialize Firebase
    initialize_firebase()
    
    # Fetch MINUTE-LEVEL data from Firebase
    df_minutes = fetch_firebase_data(hours=168)  # Fetch last 7 days of minute data
    
    # Extract hourly readings (one reading per hour, no averaging)
    df_hourly = extract_hourly_readings(df_minutes)
    
    # Preprocess
    df_hourly = preprocess_data(df_hourly)
    
    # Check if we have enough data
    if len(df_hourly) < 1:
        print("❌ ERROR: No valid hourly data available after extraction.")
        print("   Please ensure your Firebase database contains PM2.5 and PM10 measurements.")
        return
    
    print(f"\n{'='*70}")
    print("DATA AVAILABILITY ASSESSMENT")
    print(f"{'='*70}")
    print(f"Total valid hourly readings: {len(df_hourly)}")
    print(f"Time span: {(df_hourly['datetime'].max() - df_hourly['datetime'].min()).total_seconds() / 3600:.1f} hours")
    print(f"Date range: {df_hourly['datetime'].min()} to {df_hourly['datetime'].max()}")
    
    # Generate features
    df_hourly = generate_features(df_hourly)
    
    print(f"Records after feature engineering: {len(df_hourly)}")
    
    if len(df_hourly) < 1:
        print("❌ ERROR: Not enough data for feature engineering.")
        print("   Need at least a few consecutive hourly measurements.")
        return
    
    # Generate forecast
    forecast_df = generate_forecast(df_hourly, hours=48)
    
    # Display results
    print("\n" + "="*70)
    print("FORECAST SUMMARY")
    print("="*70)
    print(f"\nPM2.5 Statistics:")
    print(f"  Average:  {forecast_df['pm25_forecast'].mean():.2f} μg/m³")
    print(f"  Min:      {forecast_df['pm25_forecast'].min():.2f} μg/m³")
    print(f"  Max:      {forecast_df['pm25_forecast'].max():.2f} μg/m³")
    print(f"\nPM10 Statistics:")
    print(f"  Average:  {forecast_df['pm10_forecast'].mean():.2f} μg/m³")
    print(f"  Min:      {forecast_df['pm10_forecast'].min():.2f} μg/m³")
    print(f"  Max:      {forecast_df['pm10_forecast'].max():.2f} μg/m³")
    
    # Save to Firebase
    save_forecast_to_firebase(forecast_df)
    
    # Also save locally
    output_file = f"forecast_48h_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    forecast_df.to_csv(output_file, index=False)
    print(f"\n✓ Local backup saved to: {output_file}")
    
    print("\n✓ Process completed successfully!")
    print("="*70)
    
    # Data collection recommendation
    if len(df_hourly) < 48:
        print("\n" + "="*70)
        print("RECOMMENDATION")
        print("="*70)
        print("For optimal forecast accuracy, please collect at least 48 hours of")
        print("continuous sensor data before relying on predictions.")
        print(f"Current data: ~{len(df_hourly)} hours | Target: 48+ hours")
        print("="*70)

if __name__ == "__main__":
    main()