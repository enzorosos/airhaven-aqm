import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.model_selection import RandomizedSearchCV, TimeSeriesSplit
from scipy.stats import randint, uniform
import joblib
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)

# =====================================================
# Load and combine all CSVs
# =====================================================

try:
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    SCRIPT_DIR = os.getcwd() 

DATA_DIR = os.path.join(SCRIPT_DIR, "historical_data")
all_dfs = []
combined_df = pd.DataFrame()

try:
    if not os.path.isdir(DATA_DIR):
        print(f"Directory '{DATA_DIR}' not found. Check your folder placement.")
        raise FileNotFoundError 
        
    csv_files = [f for f in os.listdir(DATA_DIR) if f.endswith(".csv")]
    print(f"\nFound {len(csv_files)} CSV file(s) in '{DATA_DIR}':")
    
    for file in csv_files:
        print(f"  Loading: {file}")
        df = pd.read_csv(os.path.join(DATA_DIR, file))
        all_dfs.append(df)
    
    if not all_dfs:
        raise FileNotFoundError 

    combined_df = pd.concat(all_dfs, ignore_index=True)
    
    # Parse datetime
    combined_df['datetime'] = pd.to_datetime(combined_df['Date & Time'], format='mixed', errors='coerce')
    combined_df = combined_df.dropna(subset=['datetime'])
    
    # Rename columns
    combined_df = combined_df.rename(columns={
        'PM25 Conc.': 'components.pm2_5',
        'PM10 Conc.': 'components.pm10'
    })
    
    min_date = combined_df['datetime'].min().strftime('%Y-%m-%d')
    max_date = combined_df['datetime'].max().strftime('%Y-%m-%d')
    print(f"\nData Loaded Successfully!")
    print(f"Date Range: {min_date} to {max_date}")
    print(f"Total rows: {len(combined_df)}")

except FileNotFoundError:
    print(f"\nERROR: Data loading failed.")
    exit()

# =====================================================
# Initial Data Preparation
# =====================================================
df = combined_df[['datetime', 'components.pm2_5', 'components.pm10']].copy()
df = df.sort_values('datetime').reset_index(drop=True)

print(f"\nInitial data points: {len(df)}")

def clean_pm_value(x):
    if isinstance(x, str):
        x = x.replace('μg/m³', '').replace('ug/m3', '').replace(',', '').strip()
    try:
        return float(x)
    except:
        return np.nan

df['components.pm2_5'] = df['components.pm2_5'].apply(clean_pm_value)
df['components.pm10'] = df['components.pm10'].apply(clean_pm_value)

# =====================================================
# DATA CLEANING
# =====================================================
print("\n" + "="*70)
print("DATA CLEANING & QUALITY ANALYSIS")
print("="*70)

pm25_missing_initial = df['components.pm2_5'].isna().sum()
pm10_missing_initial = df['components.pm10'].isna().sum()
total_rows = len(df)

print(f"\nInitial missing values:")
print(f"  PM2.5: {pm25_missing_initial} ({pm25_missing_initial/total_rows*100:.2f}%)")
print(f"  PM10: {pm10_missing_initial} ({pm10_missing_initial/total_rows*100:.2f}%)")

# Only remove physically impossible values
for col in ['components.pm2_5', 'components.pm10']:
    df.loc[(df[col] < 0) | (df[col] > 1000), col] = np.nan

print(f"\nValid measurements:")
print(f"  PM2.5: {df['components.pm2_5'].notna().sum()}/{total_rows} ({df['components.pm2_5'].notna().sum()/total_rows*100:.1f}%)")
print(f"  PM10: {df['components.pm10'].notna().sum()}/{total_rows} ({df['components.pm10'].notna().sum()/total_rows*100:.1f}%)")

# =====================================================
# ENHANCED FEATURE ENGINEERING
# =====================================================
print("\n" + "="*70)
print("ENHANCED FEATURE ENGINEERING")
print("="*70)

# Data quality features
df['pm2_5_is_missing'] = df['components.pm2_5'].isna().astype(int)
df['pm10_is_missing'] = df['components.pm10'].isna().astype(int)
df['pm2_5_missing_count_6h'] = df['pm2_5_is_missing'].rolling(window=6, min_periods=1).sum()
df['pm10_missing_count_6h'] = df['pm10_is_missing'].rolling(window=6, min_periods=1).sum()

# Imputation for feature engineering
df['pm2_5_imputed'] = df['components.pm2_5'].ffill(limit=3).fillna(df['components.pm2_5'].median())
df['pm10_imputed'] = df['components.pm10'].ffill(limit=3).fillna(df['components.pm10'].median())

# Temporal features
df['month'] = df['datetime'].dt.month
df['day'] = df['datetime'].dt.day
df['dayofweek'] = df['datetime'].dt.dayofweek
df['hour'] = df['datetime'].dt.hour 
df['is_weekend'] = (df['dayofweek'] >= 5).astype(int)
df['is_dry_season'] = df['month'].isin([11, 12, 1, 2, 3, 4]).astype(int)

# Cyclical encoding
df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)

# Rush hour indicator
df['is_rush_hour'] = df['hour'].isin([7, 8, 9, 17, 18, 19, 20]).astype(int)

# Extended lag features
for lag in range(1, 13):
    df[f'pm2_5_lag{lag}'] = df['pm2_5_imputed'].shift(lag)
    df[f'pm10_lag{lag}'] = df['pm10_imputed'].shift(lag)

# Lag interactions
df['pm_ratio_lag1'] = df['pm2_5_lag1'] / (df['pm10_lag1'] + 1)
df['pm_ratio_lag3'] = df['pm2_5_lag3'] / (df['pm10_lag3'] + 1)
df['pm_diff_lag1'] = df['pm10_lag1'] - df['pm2_5_lag1']

# Enhanced rolling statistics
windows = [3, 6, 12, 24, 48]
for window in windows:
    min_periods = max(1, int(window * 0.5))
    
    df[f'pm2_5_roll_median_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).median().shift(1)
    df[f'pm10_roll_median_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).median().shift(1)
    df[f'pm2_5_roll_std_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).std().shift(1)
    df[f'pm10_roll_std_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).std().shift(1)
    df[f'pm2_5_roll_min_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).min().shift(1)
    df[f'pm2_5_roll_max_{window}h'] = df['pm2_5_imputed'].rolling(window=window, min_periods=min_periods).max().shift(1)
    df[f'pm10_roll_min_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).min().shift(1)
    df[f'pm10_roll_max_{window}h'] = df['pm10_imputed'].rolling(window=window, min_periods=min_periods).max().shift(1)

# Rate of change features
for lag in [1, 3, 6]:
    df[f'pm2_5_change_{lag}h'] = df['pm2_5_imputed'].diff(lag)
    df[f'pm10_change_{lag}h'] = df['pm10_imputed'].diff(lag)

# Acceleration
df['pm2_5_accel'] = df['pm2_5_change_1h'].diff(1)
df['pm10_accel'] = df['pm10_change_1h'].diff(1)

# Exponential weighted moving average
df['pm2_5_ewm_12h'] = df['pm2_5_imputed'].ewm(span=12).mean().shift(1)
df['pm10_ewm_12h'] = df['pm10_imputed'].ewm(span=12).mean().shift(1)

print("Enhanced features created (90 total features)")

# Prepare training data
df_for_training = df.dropna(subset=['components.pm2_5', 'components.pm10']).copy()
df_for_training = df_for_training.dropna().reset_index(drop=True)

retained = len(df_for_training) / len(df) * 100
print(f"Rows for training: {len(df_for_training)} ({retained:.1f}% retention)")

# =====================================================
# Train-test split
# =====================================================
if len(df_for_training) < 100:
    print(f"\nERROR: Not enough data ({len(df_for_training)} rows)")
    exit()

split_index = int(len(df_for_training) * 0.7)
train_df = df_for_training.iloc[:split_index]
test_df = df_for_training.iloc[split_index:]

# Define features
TEMPORAL_FEATURES = ['month', 'day', 'dayofweek', 'hour', 'is_weekend', 'is_dry_season', 
                     'hour_sin', 'hour_cos', 'month_sin', 'month_cos', 'is_rush_hour']

LAG_FEATURES = [f'pm2_5_lag{i}' for i in range(1, 13)] + [f'pm10_lag{i}' for i in range(1, 13)]
INTERACTION_FEATURES = ['pm_ratio_lag1', 'pm_ratio_lag3', 'pm_diff_lag1']

ROLLING_FEATURES = []
for window in [3, 6, 12, 24, 48]:
    ROLLING_FEATURES.extend([
        f'pm2_5_roll_median_{window}h', f'pm10_roll_median_{window}h',
        f'pm2_5_roll_std_{window}h', f'pm10_roll_std_{window}h',
        f'pm2_5_roll_min_{window}h', f'pm2_5_roll_max_{window}h',
        f'pm10_roll_min_{window}h', f'pm10_roll_max_{window}h'
    ])

CHANGE_FEATURES = [f'pm2_5_change_{i}h' for i in [1, 3, 6]] + \
                  [f'pm10_change_{i}h' for i in [1, 3, 6]] + \
                  ['pm2_5_accel', 'pm10_accel']

EWM_FEATURES = ['pm2_5_ewm_12h', 'pm10_ewm_12h']
QUALITY_FEATURES = ['pm2_5_missing_count_6h', 'pm10_missing_count_6h']

MODEL_FEATURES = (TEMPORAL_FEATURES + LAG_FEATURES + INTERACTION_FEATURES + 
                  ROLLING_FEATURES + CHANGE_FEATURES + EWM_FEATURES + QUALITY_FEATURES)

print(f"\n{'='*70}")
print(f"TRAINING CONFIGURATION")
print(f"{'='*70}")
print(f"Training set: {len(train_df)} samples")
print(f"Test set: {len(test_df)} samples")
print(f"Features used: {len(MODEL_FEATURES)}")
print(f"Train date range: {train_df['datetime'].min()} to {train_df['datetime'].max()}")
print(f"Test date range: {test_df['datetime'].min()} to {test_df['datetime'].max()}")

# =====================================================
# GRADIENT BOOSTING MODEL TRAINING
# =====================================================
def train_gradient_boosting(target_col, ax):
    print(f"\n{'='*70}")
    print(f"GRADIENT BOOSTING MODEL TRAINING for {target_col.upper()}")
    print("="*70)
    
    X_train = train_df[MODEL_FEATURES]
    y_train = train_df[target_col]
    X_test = test_df[MODEL_FEATURES]
    y_test = test_df[target_col]

    print("\nOptimizing hyperparameters with RandomizedSearchCV...")
    
    gb_param_grid = {
        'n_estimators': randint(200, 1000),
        'learning_rate': uniform(0.01, 0.19),
        'max_depth': randint(3, 10),
        'min_samples_split': randint(2, 15),
        'min_samples_leaf': randint(1, 8),
        'subsample': uniform(0.7, 0.3),
        'max_features': ['sqrt', 'log2', 0.5],
    }
    
    gb = GradientBoostingRegressor(random_state=42)
    tscv = TimeSeriesSplit(n_splits=3)
    
    gb_search = RandomizedSearchCV(
        estimator=gb, 
        param_distributions=gb_param_grid, 
        n_iter=30,
        scoring='neg_mean_squared_error', 
        cv=tscv,
        verbose=1,
        random_state=42, 
        n_jobs=-1
    )
    
    gb_search.fit(X_train, y_train)
    best_model = gb_search.best_estimator_
    
    print(f"\n✓ Training Complete!")
    print(f"\nBest Hyperparameters:")
    for param, value in gb_search.best_params_.items():
        print(f"  {param}: {value}")
    
    # ===== EVALUATE MODEL =====
    print(f"\n{'='*70}")
    print("MODEL PERFORMANCE")
    print("="*70)
    
    y_pred = best_model.predict(X_test)
    y_train_pred = best_model.predict(X_train)
    
    # Test set metrics
    r2_test = r2_score(y_test, y_pred)
    rmse_test = np.sqrt(mean_squared_error(y_test, y_pred))
    mae_test = mean_absolute_error(y_test, y_pred)
    mape_test = np.mean(np.abs((y_test - y_pred) / (y_test + 0.1))) * 100
    median_ae_test = np.median(np.abs(y_test - y_pred))
    
    # Training set metrics
    r2_train = r2_score(y_train, y_train_pred)
    rmse_train = np.sqrt(mean_squared_error(y_train, y_train_pred))
    
    print(f"\nTest Set Performance:")
    print(f"  R² Score:  {r2_test:.4f} {'✓ Excellent!' if r2_test > 0.95 else '✓ Good!' if r2_test > 0.90 else ''}")
    print(f"  RMSE:      {rmse_test:.3f} μg/m³")
    print(f"  MAE:       {mae_test:.3f} μg/m³")
    print(f"  Median AE: {median_ae_test:.3f} μg/m³")
    print(f"  MAPE:      {mape_test:.2f}%")
    
    print(f"\nTraining Set Performance:")
    print(f"  R² Score:  {r2_train:.4f}")
    print(f"  RMSE:      {rmse_train:.3f} μg/m³")
    
    overfit_check = r2_train - r2_test
    if overfit_check < 0.05:
        print(f"\n✓ Model is well-generalized (overfitting: {overfit_check:.4f})")
    else:
        print(f"\n⚠ Minor overfitting detected (difference: {overfit_check:.4f})")
    
    # Feature importance
    if hasattr(best_model, 'feature_importances_'):
        feature_importance = pd.DataFrame({
            'feature': MODEL_FEATURES,
            'importance': best_model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print(f"\nTop 10 Most Important Features:")
        for idx, row in feature_importance.head(10).iterrows():
            print(f"  {row['feature']}: {row['importance']:.4f}")
    
    # Save model
    os.makedirs("saved_models", exist_ok=True)
    model_name = target_col.replace('.', '_')
    model_path = os.path.join("saved_models", f"{model_name}_gradient_boosting.pkl")
    joblib.dump(best_model, model_path)
    print(f"\n✓ Model saved to {model_path}")
    
    # ===== PLOT RESULTS =====
    full_actual = pd.concat([y_train, y_test])
    full_predicted = np.concatenate([y_train_pred, y_pred])
    full_dates = pd.concat([train_df['datetime'], test_df['datetime']])
    
    ax.plot(full_dates, full_actual, color='red', label='Actual', alpha=0.7, linewidth=1)
    ax.plot(full_dates, full_predicted, color='blue', label='Predicted (Gradient Boosting)', alpha=0.6, linewidth=1)
    
    split_date = test_df['datetime'].iloc[0]
    ax.axvline(x=split_date, color='green', linestyle='--', alpha=0.5, linewidth=2, label='Train/Test Split')
    
    ax.set_xlabel("Date")
    ax.set_ylabel(f"{target_col.upper()} (μg/m³)")
    title = f"{target_col.upper()} - Gradient Boosting (R²={r2_test:.4f}, RMSE={rmse_test:.2f}, MAE={mae_test:.2f})"
    ax.set_title(title)
    ax.legend()
    ax.tick_params(axis='x', rotation=30)
    ax.grid(True, alpha=0.3)
    
    return {
        'model': best_model,
        'r2': r2_test,
        'rmse': rmse_test,
        'mae': mae_test,
        'mape': mape_test,
        'median_ae': median_ae_test
    }

# =====================================================
# Train Models
# =====================================================
print("\n" + "="*70)
print("TRAINING GRADIENT BOOSTING MODELS")
print("="*70)

fig, axes = plt.subplots(2, 1, figsize=(16, 10), sharex=True)

# Train PM2.5
pm25_results = train_gradient_boosting('components.pm2_5', axes[0])

# Train PM10
pm10_results = train_gradient_boosting('components.pm10', axes[1])

# =====================================================
# FINAL SUMMARY
# =====================================================
print("\n" + "="*70)
print("FINAL RESULTS")
print("="*70)

print(f"\nPM2.5 Model Performance:")
print(f"  R² Score:  {pm25_results['r2']:.4f} {'✓ Excellent!' if pm25_results['r2'] > 0.95 else ''}")
print(f"  RMSE:      {pm25_results['rmse']:.3f} μg/m³")
print(f"  MAE:       {pm25_results['mae']:.3f} μg/m³")
print(f"  Median AE: {pm25_results['median_ae']:.3f} μg/m³")
print(f"  MAPE:      {pm25_results['mape']:.2f}%")

print(f"\nPM10 Model Performance:")
print(f"  R² Score:  {pm10_results['r2']:.4f} {'✓ Excellent!' if pm10_results['r2'] > 0.95 else ''}")
print(f"  RMSE:      {pm10_results['rmse']:.3f} μg/m³")
print(f"  MAE:       {pm10_results['mae']:.3f} μg/m³")
print(f"  Median AE: {pm10_results['median_ae']:.3f} μg/m³")
print(f"  MAPE:      {pm10_results['mape']:.2f}%")

print("\n" + "="*70)
print("GRADIENT BOOSTING ADVANTAGES:")
print("="*70)
print("✓ Sequential learning corrects errors from previous trees")
print("✓ Excellent handling of complex non-linear relationships")
print("✓ Built-in regularization through learning rate")
print("✓ Strong predictive performance on time series data")
print("✓ Robust to outliers and missing data patterns")
print("="*70)

plt.tight_layout()
plt.show()

print("\n✓ Model Training Complete!")
print(f"✓ Models saved in 'saved_models/' folder")
print(f"✓ Use 'components_pm2_5_gradient_boosting.pkl' for PM2.5 predictions")
print(f"✓ Use 'components_pm10_gradient_boosting.pkl' for PM10 predictions")