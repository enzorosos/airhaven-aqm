// ===== FIREBASE IMPORTS AND CONFIGURATION =====
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js';
import { getDatabase, ref, onValue, query, orderByChild, limitToLast } from 'https://www.gstatic.com/firebasejs/12.5.0/firebase-database.js';

// Firebase Configuration - REPLACE WITH YOUR ACTUAL VALUES
const firebaseConfig = {
    apiKey: "AIzaSyCXlbZGGcmYaIXRnx-jMOxSv3nB-dgqucg",
    authDomain: "airhaven-database.firebaseapp.com",
    databaseURL: "https://airhaven-database-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "airhaven-database",
    storageBucket: "airhaven-database.firebasestorage.app",
    messagingSenderId: "975540682387",
    appId: "1:975540682387:web:788e358198c6c4bef19766",
    measurementId: "G-QRMPX0XK5J"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

// ===== LOADING SCREEN =====
window.addEventListener('load', () => {
    setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
    }, 500);
});

// ===== NAVIGATION =====
const pageTitle = document.getElementById('page-title');
const toggleBtn = document.getElementById('sidebar-toggle');
const navItems = document.querySelectorAll('.nav-menu li');
const pages = document.querySelectorAll('.page');

navItems.forEach(item => {
    item.addEventListener('click', () => {
        const pageName = item.getAttribute('data-page');
        const newTitle = item.querySelector('span').textContent;
        
        navItems.forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');
        
        pages.forEach(page => page.classList.remove('active'));
        const targetPage = document.getElementById(pageName);
        if (targetPage) {
            targetPage.classList.add('active');
        }
        
        pageTitle.textContent = newTitle;
        mainContent.scrollTo(0,0);
    });
});

function navigateToPage(pageId) {
    const targetNavItem = document.querySelector(`.nav-menu li[data-page="${pageId}"]`);
    if (targetNavItem) {
        targetNavItem.click();
    }
}

// ===== UTILITY FUNCTIONS =====
function updateTimestamp(timestamp = null) {
    const now = timestamp ? new Date(timestamp) : new Date();
    const options = { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit', 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
    };
    const timestampElement = document.getElementById('last-updated');
    if (timestampElement) {
        timestampElement.textContent = `Last Updated: ${now.toLocaleString('en-US', options)} (Local Time)`;
    }
}

function hexToRgba(hex, alpha) {
    if (!hex || hex.length < 4) hex = '#FFFFFF';
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// ===== AQI CALCULATION =====
function calculateAQIFromPM25(pm25) {
    let aqi, status, color, position;
    function lin(Ih, Il, Ch, Cl, C) {
        return Math.round(((Ih - Il) / (Ch - Cl)) * (C - Cl) + Il);
    }

    if (pm25 >= 0 && pm25 <= 12.0) { aqi = lin(50, 0, 12.0, 0, pm25); status = 'Good'; color = '#2dd4bf'; position = (aqi / 50) * 16.6; }
    else if (pm25 > 12.0 && pm25 <= 35.4) { aqi = lin(100, 51, 35.4, 12.1, pm25); status = 'Moderate'; color = '#fbbf24'; position = 16.6 + ((aqi - 50) / 50) * 16.7; }
    else if (pm25 > 35.4 && pm25 <= 55.4) { aqi = lin(150, 101, 55.4, 35.5, pm25); status = 'Poor'; color = '#fb923c'; position = 33.3 + ((aqi - 100) / 50) * 16.7; }
    else if (pm25 > 55.4 && pm25 <= 150.4) { aqi = lin(200, 151, 150.4, 55.5, pm25); status = 'Unhealthy'; color = '#f87171'; position = 50 + ((aqi - 150) / 50) * 16.6; }
    else if (pm25 > 150.4 && pm25 <= 250.4) { aqi = lin(300, 201, 250.4, 150.5, pm25); status = 'Severe'; color = '#c084fc'; position = 66.6 + ((aqi - 200) / 100) * 16.7; }
    else if (pm25 > 250.4) { aqi = lin(500, 301, 500.4, 250.5, pm25); aqi = Math.min(aqi, 500); status = 'Hazardous'; color = '#ef4444'; position = 83.3 + Math.min(((aqi - 300) / 100) * 16.7, 16.7); }
    else { aqi = 0; status = 'N/A'; color = '#ffffff'; position = 0; }
    
    position = Math.min(Math.max(position, 0), 100);
    return { aqi, status, color, position };
}

function getPM10Status(pm10) {
    let color, status;
    if (pm10 <= 54) { status = 'Good'; color = '#2dd4bf'; }
    else if (pm10 <= 154) { status = 'Moderate'; color = '#fbbf24'; }
    else if (pm10 <= 254) { status = 'Poor'; color = '#fb923c'; }
    else if (pm10 <= 354) { status = 'Unhealthy'; color = '#f87171'; }
    else if (pm10 <= 424) { status = 'Severe'; color = '#c084fc'; }
    else { status = 'Hazardous'; color = '#ef4444'; }
    return { color, status };
}

// ===== HEALTH TIPS DATA =====
const healthTipsData = {
    Good: {
        icon: 'fa-leaf',
        title: 'Enjoy the outdoors!',
        text: "It's a great day for outdoor activities. The air is clean and fresh."
    },
    Moderate: {
        icon: 'fa-cloud-sun',
        title: 'Generally good, but be mindful.',
        text: 'Unusually sensitive individuals should consider reducing prolonged or heavy outdoor exertion.'
    },
    Poor: {
        icon: 'fa-wind',
        title: 'Sensitive groups: Take caution.',
        text: 'People with respiratory or heart disease, the elderly, and children should limit prolonged exertion.'
    },
    Unhealthy: {
        icon: 'fa-head-side-mask',
        title: 'Limit outdoor activities.',
        text: 'Everyone, especially sensitive groups, should reduce or reschedule strenuous activities outdoors.'
    },
    Severe: {
        icon: 'fa-exclamation-triangle',
        title: 'Avoid outdoor exertion.',
        text: 'Everyone should avoid all physical activity outdoors. Sensitive groups should remain indoors.'
    },
    Hazardous: {
        icon: 'fa-biohazard',
        title: 'Stay indoors!',
        text: 'This is a health emergency. Everyone should remain indoors and keep activity levels low.'
    }
};

// ===== FIREBASE REAL-TIME LISTENER =====
function initializeFirebaseListener() {
    // Listen to real-time sensor data
    const sensorRef = ref(database, 'sensor_data/latest');
    
    onValue(sensorRef, (snapshot) => {
        const data = snapshot.val();
        
        if (data) {
            console.log('✓ Firebase data received:', data);
            updateAirQualityFromFirebase(data);
        } else {
            console.warn('⚠️ No data available from Firebase');
            // Fall back to random data if needed
            updateAirQuality();
        }
    }, (error) => {
        console.error('❌ Firebase read error:', error);
        console.log('Falling back to demo data...');
        // Fall back to random data generation
        updateAirQuality();
    });

    // Listen to historical data for charts
    loadHistoricalData();
}

// ===== UPDATE DASHBOARD FROM FIREBASE DATA =====
function updateAirQualityFromFirebase(data) {
    const pm25Card = document.getElementById('pm25-card');
    const pm10Card = document.getElementById('pm10-card');
    const pm25Health = document.getElementById('pm25-health');
    const pm10Health = document.getElementById('pm10-health');

    if (!pm25Card) return;

    const isLightMode = document.body.classList.contains('light-mode');

    // Get values from Firebase - matching your database field names
    const pm25 = parseFloat(data.PM25 || 0).toFixed(1);
    const pm10 = parseFloat(data.PM10 || 0).toFixed(1);
    const temp = parseFloat(data.temperature || 0).toFixed(1);
    const humid = parseFloat(data.humidity || 0).toFixed(0);

    // Calculate AQI and status
    const { aqi, status, color, position } = calculateAQIFromPM25(parseFloat(pm25));

    // Update main AQI display
    document.getElementById('aqi-value').textContent = aqi;
    document.getElementById('aqi-status').textContent = status;
    document.getElementById('aqi-value').style.color = color;
    document.getElementById('aqi-status').style.color = color;

    // Update AQI scale indicator
    const scaleIndicator = document.getElementById('scale-indicator');
    if (scaleIndicator) {
        scaleIndicator.style.left = position + '%';
        scaleIndicator.style.borderColor = color;
    }
    
    // Update PM2.5 card
    if (pm25Card) {
        pm25Card.style.background = `linear-gradient(135deg, ${hexToRgba(color, 0.2)}, ${hexToRgba(color, 0.1)})`;
        if (isLightMode && (status === 'Good' || status === 'Moderate')) {
            pm25Card.classList.add('dark-text-card');
        } else {
            pm25Card.classList.remove('dark-text-card');
        }
        document.getElementById('pm25-status-label').textContent = status;
    }
    
    // Update PM2.5 health impact
    const pm25HealthStatus = healthTipsData[status] || healthTipsData.Good;
    pm25Health.innerHTML = `<i class="fas ${pm25HealthStatus.icon}"></i><span>${pm25HealthStatus.text}</span>`;
    pm25Health.style.background = hexToRgba(color, 0.1); 
    pm25Health.style.borderLeftColor = color;

    // Update PM10 card
    const pm10Status = getPM10Status(parseFloat(pm10));
    
    if (pm10Card) {
        pm10Card.style.background = `linear-gradient(135deg, ${hexToRgba(pm10Status.color, 0.2)}, ${hexToRgba(pm10Status.color, 0.1)})`;
        if (isLightMode && (pm10Status.status === 'Good' || pm10Status.status === 'Moderate')) {
            pm10Card.classList.add('dark-text-card');
        } else {
            pm10Card.classList.remove('dark-text-card');
        }
        document.getElementById('pm10-status-label').textContent = pm10Status.status;
    }

    // Update PM10 health impact
    const pm10HealthStatus = healthTipsData[pm10Status.status] || healthTipsData.Good;
    pm10Health.innerHTML = `<i class="fas ${pm10HealthStatus.icon}"></i><span>${pm10HealthStatus.text}</span>`;
    pm10Health.style.background = hexToRgba(pm10Status.color, 0.1);
    pm10Health.style.borderLeftColor = pm10Status.color;

    // Update health tips section
    const tip = healthTipsData[status] || healthTipsData.Good;
    const healthContainer = document.getElementById('health-tips-container');
    if (healthContainer) {
        healthContainer.innerHTML = `
            <div class="health-tip-card">
                <i class="fas ${tip.icon}" style="color: ${color};"></i>
                <div>
                    <h4>${tip.title}</h4>
                    <p>${tip.text}</p>
                </div>
            </div>`;
    }
    
    // Update all PM and weather values
    document.getElementById('pm25-value').textContent = pm25;
    document.getElementById('pm10-value').textContent = pm10;
    document.getElementById('pm25-large').textContent = pm25;
    document.getElementById('pm10-large').textContent = pm10;
    document.getElementById('temperature').textContent = temp;
    document.getElementById('humidity').textContent = humid;

    // Update progress bars
    document.querySelector('.pm25-bar').style.width = Math.min((pm25 / 55.4) * 100, 100) + '%';
    document.querySelector('.pm10-bar').style.width = Math.min((pm10 / 154) * 100, 100) + '%';
    document.querySelector('.pm25-bar').style.background = color;
    document.querySelector('.pm10-bar').style.background = pm10Status.color;

    // Update timestamp
    updateTimestamp(data.timestamp);
}

// ===== FALLBACK: RANDOM DATA GENERATION (for demo/testing) =====
function updateAirQuality() {
    const pm25Card = document.getElementById('pm25-card');
    const pm10Card = document.getElementById('pm10-card');
    const pm25Health = document.getElementById('pm25-health');
    const pm10Health = document.getElementById('pm10-health');

    if (!pm25Card) return;

    const isLightMode = document.body.classList.contains('light-mode');

    const pm25 = (Math.random() * 60).toFixed(1);
    const pm10 = (Math.random() * 70).toFixed(1);
    const temp = Math.floor(Math.random() * 8) + 26;
    const humid = Math.floor(Math.random() * 25) + 70;

    const { aqi, status, color, position } = calculateAQIFromPM25(parseFloat(pm25));

    document.getElementById('aqi-value').textContent = aqi;
    document.getElementById('aqi-status').textContent = status;
    document.getElementById('aqi-value').style.color = color;
    document.getElementById('aqi-status').style.color = color;

    const scaleIndicator = document.getElementById('scale-indicator');
    if (scaleIndicator) {
        scaleIndicator.style.left = position + '%';
        scaleIndicator.style.borderColor = color;
    }
    
    if (pm25Card) {
        pm25Card.style.background = `linear-gradient(135deg, ${hexToRgba(color, 0.2)}, ${hexToRgba(color, 0.1)})`;
        if (isLightMode && (status === 'Good' || status === 'Moderate')) {
            pm25Card.classList.add('dark-text-card');
        } else {
            pm25Card.classList.remove('dark-text-card');
        }
        document.getElementById('pm25-status-label').textContent = status;
    }
    
    const pm25HealthStatus = healthTipsData[status] || healthTipsData.Good;
    pm25Health.innerHTML = `<i class="fas ${pm25HealthStatus.icon}"></i><span>${pm25HealthStatus.text}</span>`;
    pm25Health.style.background = hexToRgba(color, 0.1); 
    pm25Health.style.borderLeftColor = color;

    const pm10Status = getPM10Status(parseFloat(pm10));
    
    if (pm10Card) {
        pm10Card.style.background = `linear-gradient(135deg, ${hexToRgba(pm10Status.color, 0.2)}, ${hexToRgba(pm10Status.color, 0.1)})`;
        if (isLightMode && (pm10Status.status === 'Good' || pm10Status.status === 'Moderate')) {
            pm10Card.classList.add('dark-text-card');
        } else {
            pm10Card.classList.remove('dark-text-card');
        }
        document.getElementById('pm10-status-label').textContent = pm10Status.status;
    }

    const pm10HealthStatus = healthTipsData[pm10Status.status] || healthTipsData.Good;
    pm10Health.innerHTML = `<i class="fas ${pm10HealthStatus.icon}"></i><span>${pm10HealthStatus.text}</span>`;
    pm10Health.style.background = hexToRgba(pm10Status.color, 0.1);
    pm10Health.style.borderLeftColor = pm10Status.color;

    const tip = healthTipsData[status] || healthTipsData.Good;
    const healthContainer = document.getElementById('health-tips-container');
    if (healthContainer) {
        healthContainer.innerHTML = `
            <div class="health-tip-card">
                <i class="fas ${tip.icon}" style="color: ${color};"></i>
                <div>
                    <h4>${tip.title}</h4>
                    <p>${tip.text}</p>
                </div>
            </div>`;
    }
    
    document.getElementById('pm25-value').textContent = pm25;
    document.getElementById('pm10-value').textContent = pm10;
    document.getElementById('pm25-large').textContent = pm25;
    document.getElementById('pm10-large').textContent = pm10;
    document.getElementById('temperature').textContent = temp;
    document.getElementById('humidity').textContent = humid;

    document.querySelector('.pm25-bar').style.width = Math.min((pm25 / 55.4) * 100, 100) + '%';
    document.querySelector('.pm10-bar').style.width = Math.min((pm10 / 154) * 100, 100) + '%';
    document.querySelector('.pm25-bar').style.background = color;
    document.querySelector('.pm10-bar').style.background = pm10Status.color;

    updateTimestamp();
}

// ===== GRADIENT BOOSTING FORECAST FROM FIREBASE =====
function loadForecastFromFirebase() {
    console.log('📊 Loading Gradient Boosting forecast from Firebase...');
    const forecastRef = ref(database, 'sensor_data/forecast');
    
    onValue(forecastRef, (snapshot) => {
        const data = snapshot.val();
        
        if (data) {
            console.log('✓ Forecast data loaded from Firebase (Gradient Boosting Model)');
            displayGBForecast(data);
        } else {
            console.warn('⚠️ No forecast data available from GB model.');
            console.log('Run your Python script: python real-time_prediction-GB.py');
            displayForecastPlaceholder();
        }
    }, (error) => {
        console.error('❌ Error loading forecast:', error);
        displayForecastPlaceholder();
    });
}

// ===== DISPLAY GRADIENT BOOSTING FORECAST =====
function displayGBForecast(forecastData) {
    const forecastContainer = document.getElementById('forecast-container');
    if (!forecastContainer) return;
    
    let forecastHTML = '';
    const forecastArray = [];
    
    // Convert Firebase nested structure to array
    Object.keys(forecastData).forEach(dateKey => {
        // Skip metadata if it exists
        if (dateKey === 'metadata') return;
        
        const dayData = forecastData[dateKey];
        if (typeof dayData !== 'object') return;
        
        Object.keys(dayData).forEach(timeKey => {
            const entry = dayData[timeKey];
            if (entry && entry.timestamp) {
                forecastArray.push({
                    timestamp: new Date(entry.timestamp),
                    pm25: parseFloat(entry.PM25) || 0,
                    pm10: parseFloat(entry.PM10) || 0,
                    generated_at: entry.generated_at
                });
            }
        });
    });
    
    if (forecastArray.length === 0) {
        displayForecastPlaceholder();
        return;
    }
    
    // Sort by timestamp
    forecastArray.sort((a, b) => a.timestamp - b.timestamp);
    
    // Display next 24 hours
    const now = new Date();
    const next24Hours = forecastArray.filter(entry => {
        const hoursDiff = (entry.timestamp - now) / (1000 * 60 * 60);
        return hoursDiff >= 0 && hoursDiff <= 24;
    });
    
    // If no data in next 24 hours, show what's available
    const displayData = next24Hours.length > 0 ? next24Hours : forecastArray.slice(0, 24);
    
    console.log(`📈 Displaying ${displayData.length} forecast hours`);
    
    displayData.forEach((entry, index) => {
        const forecastHour = entry.timestamp.getHours();
        const forecastDate = entry.timestamp.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const pm25_forecast = Math.round(entry.pm25);
        const pm10_forecast = Math.round(entry.pm10);
        
        const pm25_status = calculateAQIFromPM25(pm25_forecast);
        const tip = healthTipsData[pm25_status.status] || healthTipsData.Good;
        
        forecastHTML += `
            <div class="forecast-item">
                <div class="forecast-time">
                    ${forecastHour.toString().padStart(2, '0')}:00
                    <small style="display: block; font-size: 0.7em; opacity: 0.7;">${forecastDate}</small>
                </div>
                <div class="forecast-icon">
                    <i class="fas ${tip.icon}" style="color: ${pm25_status.color};"></i>
                </div>
                <div class="forecast-values">
                    <div class="forecast-value-box">
                        <div class="forecast-label">PM2.5</div>
                        <div class="forecast-value">${pm25_forecast}</div>
                    </div>
                    <div class="forecast-value-box">
                        <div class="forecast-label">PM10</div>
                        <div class="forecast-value">${pm10_forecast}</div>
                    </div>
                </div>
                <div class="forecast-indicator" style="background-color: ${pm25_status.color};"></div>
                <div class="forecast-tooltip">
                    <h5>${tip.title}</h5>
                    <p>${tip.text}</p>
                    <small style="opacity: 0.7; display: block; margin-top: 5px;">
                        🤖 Gradient Boosting Model
                    </small>
                </div>
            </div>`;
    });
    
    forecastContainer.innerHTML = forecastHTML;
}

// ===== FORECAST PLACEHOLDER =====
function displayForecastPlaceholder() {
    const forecastContainer = document.getElementById('forecast-container');
    if (!forecastContainer) return;
    
    forecastContainer.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--text-secondary);">
            <i class="fas fa-chart-line" style="font-size: 3rem; opacity: 0.3; margin-bottom: 1rem;"></i>
            <h3 style="margin-bottom: 0.5rem;">No Forecast Data Available</h3>
            <p style="opacity: 0.7;">Run the Python forecasting script to generate predictions:</p>
            <code style="display: block; margin: 1rem auto; padding: 0.5rem; background: var(--card-bg); border-radius: 5px; max-width: 400px;">
                python real-time_prediction-GB.py
            </code>
            <p style="opacity: 0.5; font-size: 0.9rem; margin-top: 1rem;">
                The Gradient Boosting model will generate a 48-hour forecast based on historical data.
            </p>
        </div>`;
}

// ===== CHART GENERATION =====
let currentChartType = 'pm25';
let pm25Data = [];
let pm10Data = [];
let rawPM25Values = []; // Store all raw PM2.5 values from last 24h
let rawPM10Values = []; // Store all raw PM10 values from last 24h

function generateChart(type = 'pm25') {
    currentChartType = type;
    const chartBars = document.getElementById('chart-bars');
    const chartLabels = document.getElementById('chart-labels');
    
    if (!chartBars || !chartLabels) return;

    const currentHour = new Date().getHours();
    
    if (pm25Data.length === 0) {
        for (let i = 0; i < 24; i++) {
            const hour = (currentHour + i - 23 + 24) % 24;
            pm25Data.push({ hour, value: Math.floor(Math.random() * 30) + 5 });
            pm10Data.push({ hour, value: Math.floor(Math.random() * 45) + 10 });
        }
    }

    let displayData, maxValue, minData, maxData, avgValue;
    const formatHour = (hour) => `${hour.toString().padStart(2, '0')}:00`;

    if (type === 'pm25') {
        displayData = pm25Data;
        maxValue = Math.max(...pm25Data.map(d => d.value));
        
        // Calculate actual min/max/avg from ALL raw readings in last 24h
        if (rawPM25Values.length > 0) {
            const actualMin = Math.min(...rawPM25Values);
            const actualMax = Math.max(...rawPM25Values);
            const actualAvg = Math.round(rawPM25Values.reduce((sum, val) => sum + val, 0) / rawPM25Values.length);
            
            // Find the hour when min/max occurred
            minData = pm25Data.find(d => d.min === actualMin) || pm25Data.reduce((min, d) => d.value < min.value ? d : min);
            maxData = pm25Data.find(d => d.max === actualMax) || pm25Data.reduce((max, d) => d.value > max.value ? d : max);
            avgValue = actualAvg;
            
            document.getElementById('min-pm').textContent = actualMin;
            document.getElementById('max-pm').textContent = actualMax;
            document.getElementById('avg-pm').textContent = actualAvg;
        } else {
            minData = pm25Data.reduce((min, d) => d.value < min.value ? d : min);
            maxData = pm25Data.reduce((max, d) => d.value > max.value ? d : max);
            avgValue = Math.round(pm25Data.reduce((sum, d) => sum + d.value, 0) / pm25Data.length);
            
            document.getElementById('min-pm').textContent = minData.value;
            document.getElementById('max-pm').textContent = maxData.value;
            document.getElementById('avg-pm').textContent = avgValue;
        }
    } else {
        displayData = pm10Data;
        maxValue = Math.max(...pm10Data.map(d => d.value));
        
        // Calculate actual min/max/avg from ALL raw readings in last 24h
        if (rawPM10Values.length > 0) {
            const actualMin = Math.min(...rawPM10Values);
            const actualMax = Math.max(...rawPM10Values);
            const actualAvg = Math.round(rawPM10Values.reduce((sum, val) => sum + val, 0) / rawPM10Values.length);
            
            // Find the hour when min/max occurred
            minData = pm10Data.find(d => d.min === actualMin) || pm10Data.reduce((min, d) => d.value < min.value ? d : min);
            maxData = pm10Data.find(d => d.max === actualMax) || pm10Data.reduce((max, d) => d.value > max.value ? d : max);
            avgValue = actualAvg;
            
            document.getElementById('min-pm').textContent = actualMin;
            document.getElementById('max-pm').textContent = actualMax;
            document.getElementById('avg-pm').textContent = actualAvg;
        } else {
            minData = pm10Data.reduce((min, d) => d.value < min.value ? d : min);
            maxData = pm10Data.reduce((max, d) => d.value > max.value ? d : max);
            avgValue = Math.round(pm10Data.reduce((sum, d) => sum + d.value, 0) / pm10Data.length);
            
            document.getElementById('min-pm').textContent = minData.value;
            document.getElementById('max-pm').textContent = maxData.value;
            document.getElementById('avg-pm').textContent = avgValue;
        }
    }
    
    document.getElementById('min-time').textContent = `at ${formatHour(minData.hour)}`;
    document.getElementById('max-time').textContent = `at ${formatHour(maxData.hour)}`;
    
    const labelText = type === 'pm25' ? 'PM2.5' : 'PM10';
    document.getElementById('min-label').textContent = labelText;
    document.getElementById('max-label').textContent = labelText;
    document.getElementById('avg-label').textContent = labelText;

    chartBars.innerHTML = '';
    chartLabels.innerHTML = '';

    displayData.forEach((d, index) => {
        const height = (d.value / maxValue) * 100;
        const bar = document.createElement('div');
        bar.className = type === 'pm10' ? 'chart-bar pm10-bar' : 'chart-bar';
        bar.style.height = Math.max(height, 5) + '%';
        
        const tooltip = document.createElement('div');
        tooltip.className = 'chart-bar-tooltip';
        tooltip.textContent = `${labelText}: ${d.value} µg/m³`;
        bar.appendChild(tooltip);
        chartBars.appendChild(bar);
        
        const label = document.createElement('span');
        label.textContent = (index % 3 === 0) ? formatHour(d.hour) : '';
        chartLabels.appendChild(label);
    });
}

// ===== LOAD HISTORICAL DATA FROM FIREBASE =====
function loadHistoricalData() {
    const historicalRef = ref(database, 'sensor_data/history');
    
    onValue(historicalRef, (snapshot) => {
        const data = snapshot.val();
        
        if (data) {
            console.log('✓ Historical data loaded from Firebase');
            
            // Convert to chart format
            pm25Data = [];
            pm10Data = [];
            
            // Flatten the nested date structure
            const allEntries = [];
            
            // Get only last 2 days to improve performance
            const now = new Date();
            const twoDaysAgo = new Date(now.getTime() - (2 * 24 * 60 * 60 * 1000));
            const twoDaysAgoKey = twoDaysAgo.toISOString().split('T')[0]; // "2025-11-09"
            
            Object.keys(data).forEach(dateKey => {
                // Skip dates older than 2 days
                if (dateKey < twoDaysAgoKey) {
                    return;
                }
                
                const dayData = data[dateKey];
                if (typeof dayData === 'object') {
                    Object.keys(dayData).forEach(timeKey => {
                        const entry = dayData[timeKey];
                        if (entry && entry.timestamp) {
                            // Handle timestamp format "2025-11-11 15:26:44"
                            const timestamp = new Date(entry.timestamp.replace(' ', 'T'));
                            
                            // Validate timestamp
                            if (!isNaN(timestamp.getTime())) {
                                allEntries.push({
                                    timestamp: timestamp,
                                    PM25: parseFloat(entry.PM25) || 0,
                                    PM10: parseFloat(entry.PM10) || 0
                                });
                            } else {
                                console.warn('Invalid timestamp:', entry.timestamp);
                            }
                        }
                    });
                }
            });
            
            console.log('📥 Loaded', allEntries.length, 'data points from last 2 days');
            
            // Sort by timestamp
            allEntries.sort((a, b) => a.timestamp - b.timestamp);
            
            // Group by hour and calculate average
            const hourlyData = {};
            
            allEntries.forEach((entry) => {
                const hourKey = `${entry.timestamp.getFullYear()}-${String(entry.timestamp.getMonth() + 1).padStart(2, '0')}-${String(entry.timestamp.getDate()).padStart(2, '0')}_${String(entry.timestamp.getHours()).padStart(2, '0')}`;
                
                if (!hourlyData[hourKey]) {
                    hourlyData[hourKey] = {
                        hour: entry.timestamp.getHours(),
                        date: entry.timestamp,
                        pm25Values: [],
                        pm10Values: []
                    };
                }
                
                hourlyData[hourKey].pm25Values.push(entry.PM25);
                hourlyData[hourKey].pm10Values.push(entry.PM10);
            });
            
            // Calculate averages and take last 24 hours
            const hourlyArray = Object.values(hourlyData).map(hourData => ({
                hour: hourData.hour,
                date: hourData.date,
                pm25: Math.round(hourData.pm25Values.reduce((sum, val) => sum + val, 0) / hourData.pm25Values.length),
                pm10: Math.round(hourData.pm10Values.reduce((sum, val) => sum + val, 0) / hourData.pm10Values.length),
                pm25Min: Math.round(Math.min(...hourData.pm25Values)),
                pm25Max: Math.round(Math.max(...hourData.pm25Values)),
                pm10Min: Math.round(Math.min(...hourData.pm10Values)),
                pm10Max: Math.round(Math.max(...hourData.pm10Values)),
                readingsCount: hourData.pm25Values.length
            }));
            
            // Sort by date and take last 24 hours
            hourlyArray.sort((a, b) => a.date - b.date);
            const last24Hours = hourlyArray.slice(-24);
            
            console.log('📊 Processing', last24Hours.length, 'hours of data');
            console.log('📊 Average readings per hour:', Math.round(last24Hours.reduce((sum, h) => sum + h.readingsCount, 0) / last24Hours.length));
            
            pm25Data = [];
            pm10Data = [];
            
            last24Hours.forEach((hourData) => {
                pm25Data.push({ 
                    hour: hourData.hour,
                    value: hourData.pm25,
                    min: hourData.pm25Min,
                    max: hourData.pm25Max,
                    count: hourData.readingsCount
                });
                
                pm10Data.push({ 
                    hour: hourData.hour,
                    value: hourData.pm10,
                    min: hourData.pm10Min,
                    max: hourData.pm10Max,
                    count: hourData.readingsCount
                });
            });
            
            // Update chart with real data
            if (pm25Data.length > 0) {
                generateChart(currentChartType);
            } else {
                console.warn('⚠️ No valid entries found, using demo data');
            }
        }
    }, (error) => {
        console.warn('⚠️ Could not load historical data:', error);
        // Keep using generated demo data
    });
}

// ===== CHART CONTROLS =====
document.querySelectorAll('.chart-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.chart-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        generateChart(btn.getAttribute('data-chart'));
    });
});

// ===== SCALE TAB CONTROLS =====
document.querySelectorAll('.scale-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.scale-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const scaleType = tab.getAttribute('data-scale');
        document.getElementById('aqi-categories').style.display = scaleType === 'aqi' ? 'flex' : 'none';
        document.getElementById('pm-categories').style.display = scaleType === 'pm' ? 'flex' : 'none';
    });
});

// ===== FEEDBACK FORM =====
const feedbackForm = document.getElementById('feedback-form');
if (feedbackForm) {
    feedbackForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const successMsg = document.getElementById('feedback-success');
        successMsg.style.display = 'block';
        feedbackForm.reset();
        setTimeout(() => { successMsg.style.display = 'none'; }, 5000);
    });
}

// ===== DASHBOARD INITIALIZATION =====
function initializeDashboard() {
    console.log('🚀 Initializing AirHaven Dashboard...');
    console.log('🤖 Gradient Boosting Model Integration Active');
    
    // Initialize Firebase real-time listener for current data
    initializeFirebaseListener();
    
    // Load Gradient Boosting forecast from Firebase
    loadForecastFromFirebase();
    
    // Initialize charts with historical data
    generateChart('pm25');
    
    // Refresh forecast every hour (in case new forecast is generated)
    setInterval(loadForecastFromFirebase, 3600000); // 1 hour
    
    console.log('✓ Dashboard initialization complete');
}

// Initialize dashboard when DOM is ready
initializeDashboard();

// ===== THEME TOGGLE =====
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;
const themeIcon = themeToggle.querySelector('i');

const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'light') {
    body.classList.add('light-mode');
    themeIcon.classList.remove('fa-moon');
    themeIcon.classList.add('fa-sun');
}

themeToggle.addEventListener('click', () => {
    body.classList.toggle('light-mode');
    if (body.classList.contains('light-mode')) {
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
        localStorage.setItem('theme', 'light');
    } else {
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
        localStorage.setItem('theme', 'dark');
    }
    // Trigger a visual update with current data
    const currentPM25 = parseFloat(document.getElementById('pm25-value').textContent);
    if (!isNaN(currentPM25)) {
        // Re-apply styling with current values
        const { color } = calculateAQIFromPM25(currentPM25);
        const pm25Card = document.getElementById('pm25-card');
        const isLight = body.classList.contains('light-mode');
        if (pm25Card && color) {
            pm25Card.style.background = `linear-gradient(135deg, ${hexToRgba(color, 0.2)}, ${hexToRgba(color, 0.1)})`;
        }
    }
});

// ===== SCROLL ANIMATIONS =====
const mainContent = document.getElementById('main-content');
const animatedElements = document.querySelectorAll('.scroll-animate');

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        } else {
            entry.target.classList.remove('visible');
        }
    });
}, {
    root: mainContent,
    threshold: 0.1
});

animatedElements.forEach(el => observer.observe(el));

// ===== FORECAST SCROLL CONTROLS =====
const forecastContainer = document.getElementById('forecast-container');
const forecastPrev = document.getElementById('forecast-prev');
const forecastNext = document.getElementById('forecast-next');

function scrollForecast(direction) {
    if (!forecastContainer) return;
    const itemWidth = forecastContainer.querySelector('.forecast-item')?.offsetWidth || 200;
    const scrollAmount = (itemWidth + 12) * 5 * direction;
    forecastContainer.scrollBy({ left: scrollAmount, behavior: 'smooth' });
}

if (forecastPrev && forecastNext) {
    forecastPrev.addEventListener('click', () => scrollForecast(-1));
    forecastNext.addEventListener('click', () => scrollForecast(1));
}

// ===== EXPORT FOR GLOBAL ACCESS =====
window.navigateToPage = navigateToPage;